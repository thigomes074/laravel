<header class="d-flex justify-content-center py-3">
    <ul class="nav nav-pills">
        <li class="nav-item"><a href="/" class="nav-link active" aria-current="page">Home</a></li>
        <li class="nav-item"><a href="{{ route('student.index') }}" class="nav-link">Alunos</a></li>
        <li class="nav-item"><a href="{{ route('discipline.index') }}" class="nav-link">Disciplinas</a></li>
        <li class="nav-item"><a href="{{ route('teacher.index') }}" class="nav-link">Professores</a></li>
    </ul>
</header>
